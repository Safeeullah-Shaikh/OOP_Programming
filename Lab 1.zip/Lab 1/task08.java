import java.util.Scanner;

public class task08{
	public static void main(String args []){
	Scanner myvalue = new Scanner(System.in);
	double mile;

	System.out.println("Enter Distance in Mile : ");
	mile = myvalue.nextDouble();
	System.out.println("Distance in KM :" + (mile*1.6));
}
}
class task03{
	public static void main(String args[]){
String name="safeeullah";
int age= 21;
char gender ='M';
double GPA=3.50;
String forigner="No";
System.out.println("Name:"+name);
System.out.println("Age :"+age);
System.out.println("Gender:"+gender);
System.out.println("GPA :"+GPA);
System.out.println("forginer :"+forigner);
}
}
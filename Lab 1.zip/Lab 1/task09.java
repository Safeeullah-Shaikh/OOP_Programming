import java.util.Scanner;

public class task09{
	public static void main (String args[]){
	Scanner myvalue= new Scanner(System.in);

	System.out.println("Enter the first number :");
	double num1= myvalue.nextDouble();
	
	System.out.print("Enter the second number :");
	double num2= myvalue.nextDouble();
	
	System.out.print("Enter the operation (+,-,*,/): ");
	char operation = myvalue.next().charAt(0);
	
	double result;
	switch (operation){
	   case '+':
		result=num1+num2;
		System.out.println("The result is: "+ result);
		break;
	   case '-':
		result=num1-num2;
		System.out.print ("The result is :"+result);
		break;
	   case'*':
		result=num1*num2;
		System.out.print("The result is: "+result);
		break;
	   case'/':
		 result=num1/num2;
		 System.out.print("The result is :"+result);
		 break;
	   default:
		 System.out.println("Error: Invalid operation. please enter one of +,-,*,/");
	}
        myvalue.close();
    }
}
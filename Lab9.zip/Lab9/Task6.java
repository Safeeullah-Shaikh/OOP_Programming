import java.util.Random;

class Task6{
	public static void main(String []args){
		int []count=new int[21];

		Random random_number=new Random();

		for(int i=0;i<100;i++)
		{
			int number =random_number.nextInt(21);
			count[number]=count[number]+1;
		}

		for(int i=0;i<=20;i++)
		{
			System.out.println("Number "+i+":"+count[i]+"times");
		}
	}

}
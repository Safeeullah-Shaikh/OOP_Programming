class Task1{
	public static void main(String [] args){
		String nalo="Hello";
		String reverse="";

		for(int i=nalo.length()-1;i>=0;i--)
		{
			reverse = reverse+nalo.charAt(i);
		}

		System.out.println("reversed: "+reverse);
	}
}
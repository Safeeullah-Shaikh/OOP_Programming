class Task5{
	public static boolean isPrime(int num){
		if (num <=1)
		{
			return false;
		}

		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}

	public static int generateRandomPrime(int min, int max){
		int prime=-1;

		for(int i=min; i<=max;i++)
		{
			if(isPrime(i))
			{
				prime=i;
			}
		}
		return prime;
	}


	public static void main(String []args){
		int min=1;
		int max=80;

		int result= generateRandomPrime(min,max);
		if(result!=1)
		{
			System.out.println("Prime Found: "+result);
		}
		else
		{
			System.out.println("No prime number found in the range.");
		}
	}
}